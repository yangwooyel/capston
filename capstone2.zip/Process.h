#pragma once

#include "Board.h"

void setWeight(Board *board);

void doPut(State state, Board *board, Point1 pt); // Process.cpp

State getWinner(Board board);