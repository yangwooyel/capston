#pragma once

#include "Process.h"

Point1 AISetPos(Board board);